%% Read Me:
% This project is published for "Cluster fusion-fission dynamics in the Singapore stock exchange", 
% by Boon Kin Teh and Siew Ann Cheong.
% Please refer to the paper for more details, and cite the paper if you are using this code to perform interaction-hierarchical clustering.
% Thank you.

%% Lastest updated date:
% 08 July 2017

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Start here %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('TestSample'); % Test Sample is an artificial correlation matrix
DistanceMatrix = 1-TestSample;

[SerialIndex,Result_A] = A_HierarchicalClustering(DistanceMatrix,'complete');

[RobustClusterList,RobustLenght,Result_B] = B_DetermineRobustClusters(Result_A,1);

[RBSerialIndex,Result_C] = C_InteractionHierarchicalClustering(Result_B,'average');

IdentifiedClusterList = D_IdentifyClusters(Result_C);